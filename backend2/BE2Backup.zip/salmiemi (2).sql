-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 12.02.2020 klo 10:19
-- Palvelimen versio: 10.1.41-MariaDB-0+deb9u1
-- PHP Version: 7.0.33-0+deb9u6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salmiemi`
--

-- --------------------------------------------------------

--
-- Rakenne taululle `loppis`
--

CREATE TABLE `loppis` (
  `id` int(10) UNSIGNED NOT NULL,
  `rubrik` varchar(511) NOT NULL,
  `beskrivning` varchar(255) NOT NULL,
  `saljare` varchar(100) NOT NULL,
  `pris` int(10) NOT NULL,
  `datum` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `loppis`
--

INSERT INTO `loppis` (`id`, `rubrik`, `beskrivning`, `saljare`, `pris`, `datum`) VALUES
(1, 'Superduperbil', 'Tuff superbil', 'skurk', 50000, '2020-01-31 11:56:29'),
(2, 'Tuff tuff', 'Detta är en jätte tuff bil', 'Emil', 550, '2020-01-31 11:58:37'),
(4, 'SUper duper dator', 'Supeeer', 'Emil', 10002, '2020-01-31 12:24:43'),
(5, 'Dator', 'Bra dator', 'Emil', 100, '2020-01-31 13:04:41'),
(6, 'Telefon', 'fin telefon', 'Eme', 100, '2020-02-05 09:10:12'),
(9, 'En sak', 'Fin sak', 'Teme', 100, '2020-02-11 10:43:08'),
(11, 'Ett bord', 'fint bord', 'Eme', 100, '2020-01-31 12:21:48'),
(12, 'NÃ¥got fint', 'Tuff stuff', 'Emil', 50, '2020-02-11 13:04:46');

-- --------------------------------------------------------

--
-- Rakenne taululle `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `namn` varchar(50) NOT NULL,
  `losen` varchar(200) NOT NULL,
  `epost` varchar(100) NOT NULL,
  `roll` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Vedos taulusta `users`
--

INSERT INTO `users` (`id`, `namn`, `losen`, `epost`, `roll`, `status`) VALUES
(1, 'Emil', '0f7e7f8fdc240b9947fa370e924b175f19b35bf8540b86db2e002fd6d30bd215', 'salmiemi@arcada.fi', 'admin', 'confirmed'),
(3, 'skurk', '0f7e7f8fdc240b9947fa370e924b175f19b35bf8540b86db2e002fd6d30bd215', 'skurk@skurkiskurkku.fi', 'editor', 'unconfirmed'),
(4, 'Emelius', 'hejasn', 'eme@ememe.fi', 'user', 'confirmed'),
(5, 'eme', 'hejasn', 'eme@ememe.fi', 'user', 'unconfirmed');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loppis`
--
ALTER TABLE `loppis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `loppis`
--
ALTER TABLE `loppis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
